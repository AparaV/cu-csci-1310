#include <iostream>
#include "Date.h"
#include "Holiday.h"

using namespace std;

int main()
{
    Date d(1, 1, 1990);
    d.showDate();
    Date d2("1/2/1990");
    d2.showDate();

    Holiday h("Christmas", 12, 25, 2016);
    h.showDate();

    //cout << "Hello world!" << endl;
    return 0;
}
