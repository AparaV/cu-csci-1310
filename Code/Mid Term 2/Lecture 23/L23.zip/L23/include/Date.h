#ifndef DATE_H
#define DATE_H

#include <iostream>

class Date
{
    public:
        Date(int m, int d, int y);
        Date(std::string);
        ~Date();
        void showDate();
    protected:
        int month;
        int day;
        int year;
    private:
};

#endif // DATE_H
